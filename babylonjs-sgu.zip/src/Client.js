/// <reference path="./Engine.js" />

import engine from "./Engine.js";

engine.main();
